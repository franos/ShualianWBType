package com.zy.sualianwb.module;

public class GETPic {
    private String openid;

    public String getOpenid() {
        return openid;
    }

    public void setOpenid(String openid) {
        this.openid = openid;
    }

    @Override
    public String toString() {
        return "GETPic [openid=" + openid + "]";
    }

}
