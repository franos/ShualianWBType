package com.zy.sualianwb.module;

/**
 * Created by zz on 15/12/29.
 */
public class CrtTime {


    /**
     * bjtime : 15-12-29 05:37:02
     */

    private long bjtime;

    public long getBjtime() {
        return bjtime;
    }

    public void setBjtime(long bjtime) {
        this.bjtime = bjtime;
    }
}

