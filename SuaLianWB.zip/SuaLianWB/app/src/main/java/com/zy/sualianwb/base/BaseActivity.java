package com.zy.sualianwb.base;

import android.app.Activity;

/**
 * Created by zz on 15/12/23.
 */
public class BaseActivity extends Activity {
}
