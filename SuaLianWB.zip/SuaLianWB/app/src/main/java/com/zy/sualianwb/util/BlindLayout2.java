package com.zy.sualianwb.util;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.LinearLayout;

/**
 * Created by zz on 15/12/30.
 */
public class BlindLayout2 extends LinearLayout {

    public BlindLayout2(Context context) {
        super(context);
    }

    public BlindLayout2(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public BlindLayout2(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
